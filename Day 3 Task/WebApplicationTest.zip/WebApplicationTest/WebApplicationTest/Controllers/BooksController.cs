﻿using Microsoft.AspNetCore.Mvc;
using BookAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace BookAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private static List<Book> books = new List<Book>
        {
            new Book { BookID = 1, BookName = "BookName1", BookAuthor = "AuthorName1" },
            new Book { BookID = 2, BookName = "BookName2", BookAuthor = "AuthorName2" }
        };

        // Display All
        [HttpGet("/DisplayAll")]
        public ActionResult<IEnumerable<Book>> GetBooks()
        {
            return books;
        }

        // For Finding Book By ID
        [HttpGet("{id}/Find")]
        public ActionResult<Book> GetBook(int id)
        {
            var book = books.FirstOrDefault(b => b.BookID == id);
            if (book == null)
                return NotFound();
            return book;
        }

        // For Addiing Book
        [HttpPost("/Add")]
        public ActionResult<Book> AddBook(Book newBook)
        {
            if (books.Any(b => b.BookID == newBook.BookID))
                return BadRequest("Book with the same ID already exists.");

            books.Add(newBook);
            return CreatedAtAction(nameof(GetBook), new { id = newBook.BookID }, newBook);
        }

        // For Updating Book
        [HttpPut("{id}/Update")]
        public IActionResult UpdateBook(int id, [FromBody] Book updatedBook)
        {
            var book = books.FirstOrDefault(b => b.BookID == id);
            if (book == null)
                return NotFound();

            book.BookID = updatedBook.BookID;
            book.BookName = updatedBook.BookName;
            book.BookAuthor = updatedBook.BookAuthor;
            return Ok(book);
        }

        // For Deleting Book
        [HttpDelete("{id}/Delete")]
        public IActionResult DeleteBook(int id)
        {
            var book = books.FirstOrDefault(b => b.BookID == id);
            if (book == null)
                return NotFound();

            books.Remove(book);
            return Ok(new { message = "Book deleted successfully" });
        }
    }
}
